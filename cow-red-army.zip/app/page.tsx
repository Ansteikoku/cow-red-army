export default function HomePage() {
  return (
    <div className="text-center space-y-10">
      <section>
        <img
          src="/flag.png"
          alt="COW赤軍旗"
          className="mx-auto w-64 h-auto rounded-lg shadow-lg border-4 border-red-800 animate-pulse"
        />
        <h1 className="text-5xl font-extrabold mt-6 text-red-400 drop-shadow-lg">
          COW赤軍 公式サイト
        </h1>
        <p className="text-gray-400 mt-2">戦略・情報・思想を統べる赤の軍団</p>
      </section>

      <section className="bg-red-950/60 p-6 rounded-xl shadow-inner max-w-2xl mx-auto">
        <h2 className="text-2xl font-bold text-yellow-300 mb-4">📢 最新ニュース</h2>
        <ul className="space-y-2 text-left mx-auto max-w-md">
          <li>・新イベント「赤潮作戦」開始！</li>
          <li>・艦艇生産ライン改良アップデート予定</li>
          <li>・新規参謀候補募集中</li>
        </ul>
      </section>

      <section className="text-gray-300 space-y-1">
        <h2 className="text-xl font-bold text-red-400">運営団体</h2>
        <p>COW赤軍本部</p>
        <p>公式SNS（仮）: <span className="text-yellow-400">@cow_red_official</span></p>
      </section>
    </div>
  )
}