const nextConfig = {
  output: 'standalone',
  experimental: { serverActions: true },
  reactStrictMode: true,
}

module.exports = nextConfig